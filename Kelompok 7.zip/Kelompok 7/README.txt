=====================================
Data Anggota Kelompok 7		    |
=====================================
- Wahyuda Abdia Putra (00000060638) |  
- Rasyid Alim Aulia (00000061628)   |
- Ivandy Wijaya (00000061844)	    |
- Pra Yoga Wijaya (00000061956)	    |
-------------------------------------

================================================================================================================================
							PERATURAN PERMAINAN
================================================================================================================================
1. Player di minta untuk menyelesaikan pendidikan mereka dalam game.
   - Dalam game akan ditampilkan 4 bar dimana, pada masing-masing bar akan sangat berpengaruh pada permainan.
   - Pada masing-masing bar ditunjukkan 4 icon yang merepresentasikan bar tersebut.
   - Terdapat juga button yang jika di klik dapat meningkatkan presentase bar tersebut.

2. Untuk menyelesaikan game ini, pemain harus menaikkan semester hingga ke semester 8(100%). Untuk meningkatkan semester
   pemain harus meningkatkan bar yang memiliki icon buku hingga mencapai 100%.

3. Pada awal permainan, pemain akan memulai di waktu 00.00 & bar makan, main, dan tidur akan dimulai pada persentase 50%.

4. Jika pemain tidak memasukkan nama di awal game, maka nama pemain akan di set sebagai anonim.

5. Konfigurasi waktu yang digunakan pada permainan ini adalah 20 menit untuk 1 detik(s) dunia nyata.

6. Saat sebuah button di klik, seluruh button yang ada akan disabled. Saat seluruh proses penambahan selesai, seluruh button akan
   di enable kembali. Tetapi, Player disarankan untuk menunggu sampai pertambahan bar yang di klik menyelesaikan prosesnya.
   - Waktu tunggu makan    : 3 detik dunia nyata (80 menit dunia game).
   - Waktu tunggu main     : 6 detik dunia nyata (120 menit dunia game).
   - Waktu tunggu tidur    : 18 detik dunia nyata (360 menit dunia game).
   - Waktu tunggu Belajar  : 6 detik dunia nyata (120 menit dunia game).

7. Mekanisme Button & Bar:
   - Masing-masing bar akan berkurang 0,5% per 20 menit ketika idle (tidak sedang melakukan kegiatan apa pun), kecuali
     bar Belajar.

   - Button Makan:
	- Meningkatkan persentase bar Makan sebanyak 60% (20%/20 menit).
	- Durasi kegiatan makan adalah 60 menit / 1 Jam
	- Pada saat makan, persentase bar yang lain akan menurun (kecuali bar Belajar). 
	  Bar Main akan berkurang sebesar 6% dan bar Tidur akan berkurang sebesar 6%.

   - Button Main:
	- Meningkatkan persentase bar Main sebanyak 60%
	- Durasi kegiatan main adalah 120 menit / 2 jam
	- Pada saat bermain, persentase bar yang lain akan menurun (kecuali bar Belajar).
	  Bar Makan akan berkurang sebesar 12% dan bar Tidur akan berkurang sebesar 9%.

   - Button Tidur:
	- Meningkatkan persentase bar Tidur sebanyak 54%
	- Durasi kegiatan tidur adalah 360 menit / 6 jam
	- Pada saat tidur, persentase bar yang lain akan menurun (kecuali bar Belajar).
	  Bar Makan akan berkurang sebesar 36% dan bar Main akan berkurang sebesar 27%

   - Button Belajar:
	- Durasi kegiatan belajar adalah 120 menit / 2 jam
	- Pada saat Belajar, persentase bar yang lain akan menurun.
	  * Jika salah satu status bar (makan/main/tidur) memiliki persentase >= 90% dan dua sisanya
	    diatas 30%, maka status belajar akan meningkat sebanyak 24% (4% per detik dunia nyata).
	  * Jika terdapat satu atau lebih status bar memiliki persentase status bar dibawah 30%, maka
	    status belajar akan meningkat sebanyak 9% (1.5% per detik dunia nyata)
	  * Untuk Kondisi lain, peningkatan status belajar akan bertambah sebanyak 15% (2.5% per detik dunia nyata).
	  * Pada ketiga point di atas, apabila selama proses belajar kondisi peningkatan tertentu tidak terpenuhi,
            maka peningkatan status belajar akan menyesuaikan dengan kondisi yang ada, dimana dapat terjadi perubahan
	    peningkatan status antara ketiga point tersebut. Contohnya: Saat sedang dalam proses belajar, peningkatan
	    yang terjadi adalah 4% + 4% + 4% + 4% + 2.5% + 2.5% = 21%. 

8. Mekanisme Warning & Game Over
   - Warning akan muncul apabila terdapat satu atau lebih status bar(makan/main/tidur) memiliki persentase dibawah 15%.
   - Warning untuk status belajar akan muncul apabila tidak ada peningkatan status belajar selama 144 detik dunia nyata 
     (2 hari dunia game).
   - Player/pemain akan mengalami Game Over apabila terdapat salah satu status bar (makan/main/tidur) memiliki persentase 0%.
   - Player/pemain akan mengalami Game Over apabila tidak terdapat peningkatan status belajar selama 216 detik dunia nyata 
     (3 hari dunia game).

================================================================================================================================
Catatan : Musik hanya bisa dimatikan, tidak bisa dihidupkan kembali.